local QBCore = exports['qb-core']:GetCoreObject()


local function CreateConfiguredBlips()
    for _, blip in ipairs(Config.Blips) do
        local b = AddBlipForCoord(blip.coords.x, blip.coords.y, blip.coords.z)
        SetBlipSprite(b, blip.sprite)
        SetBlipDisplay(b, 4) 
        SetBlipScale(b, blip.scale or 0.8)
        SetBlipColour(b, blip.color or 1)
        SetBlipAsShortRange(b, false)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentSubstringPlayerName(blip.name)
        EndTextCommandSetBlipName(b)
    end
end


CreateThread(function()
    Wait(1000) 
    CreateConfiguredBlips()
end)
