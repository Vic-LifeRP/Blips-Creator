Config = {}

--a very simple blip creator made for qbcore with love from the viclifeRP crew - simply follow the example below to add more blips.

--for sprites, color, etc visit https://docs.fivem.net/docs/game-references/blips/

--this is a FREE resouce and i will not offer support on this. but feel free to join my server discord https://discord.gg/JTWrXAq7Yc as we often
-- give out free scprits!

--example   
--    {
--        name = "Start Farming",
--        coords = vector3(2564.66, 4680.89, 34.09),
--        sprite = 674,
--        color = 46,
--        scale = 0.7
--    }, 


Config.Blips = {
    {
        name = "Start Farming",
        coords = vector3(2564.66, 4680.89, 34.09),
        sprite = 674,
        color = 46,
        scale = 0.7
    },
        {
        name = "Cow Farm",
        coords = vector3(2451.89, 4754.6, 34.3),
        sprite = 540,
        color = 81,
        scale = 0.7
    }

}
