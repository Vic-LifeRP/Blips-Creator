fx_version 'cerulean'
game 'gta5'

author 'Mrfluffernoofle'
description 'blip creator'
version '1.0.0'

client_scripts {
    'config.lua',
    'client.lua'
}
